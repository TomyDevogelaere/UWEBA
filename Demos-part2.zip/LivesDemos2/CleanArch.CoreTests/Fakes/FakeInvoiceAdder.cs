﻿using CleanArch.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArch.CoreTests.Fakes
{
  class FakeInvoiceAdder : IInvoiceAdder
  {
    public void Add(string input)
    {
      // fake db
    }
  }
}
