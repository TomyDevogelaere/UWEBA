﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CleanArch.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CleanArch.CoreTests.Fakes;

namespace CleanArch.Core.Tests
{
  [TestClass()]
  public class InvoiceProcessorTests
  {
    [TestMethod()]
    public void CalculateDebtTest()
    {
      var sut = new InvoiceProcessor(new FakeInvoiceAdder());
      sut.CalculateDebt();

      Assert.Fail();
    }
  }
}