﻿using Microsoft.ApplicationInsights;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebAppForAzure.Models;

namespace WebAppForAzure.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private readonly TelemetryClient telemetry;

    public HomeController(ILogger<HomeController> logger, TelemetryClient telemetry)
    {
      _logger = logger;
      this.telemetry = telemetry;
    }

    public IActionResult Index([FromServices] IConfiguration configuration)
    {
      ViewBag.Environment = configuration["Environment"];
      telemetry.TrackEvent("IndexVisit", new Dictionary<string,string>{ 
        ["Environment"] = ViewBag.Environment,
        ["User"]= "Lander"
      });

      var rnd = new Random();
      telemetry.TrackMetric("uploadsize", rnd.Next(100,500));

      return View();
    }

    public IActionResult Privacy()
    {
      CheckPrivacy();
      return View();
    }

    private void CheckPrivacy()
    {
      throw new Exception("No Privacy!");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}
