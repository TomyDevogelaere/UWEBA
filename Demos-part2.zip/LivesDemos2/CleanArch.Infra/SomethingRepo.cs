﻿using CleanArch.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArch.Infra
{
  public class SomethingRepo : IInvoiceAdder, IInvoiceDeleter
  {
    public void Add(string input) { }
    public void Delete(string input) { }
  }
}
