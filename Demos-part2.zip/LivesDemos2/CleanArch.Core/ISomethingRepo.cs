﻿namespace CleanArch.Core
{
  public interface IInvoiceAdder
  {
    void Add(string input);
  }

  public interface IInvoiceDeleter
  {
    void Delete(string input);
  }

}