﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArch.Core
{
  public class InvoiceProcessor
  {
    private readonly IInvoiceAdder adder;

    public InvoiceProcessor(IInvoiceAdder repo)
    {
      this.adder = repo;
    }

    public void CalculateDebt()
    { 
      adder.Add("black");
    }


  }
}
