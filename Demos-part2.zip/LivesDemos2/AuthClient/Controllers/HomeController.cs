﻿using AuthClient.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Web;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AuthClient.Controllers
{
  [Authorize]
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private readonly HttpClient client;

    public HomeController(ILogger<HomeController> logger, HttpClient httpClient)
    {
      _logger = logger;
      this.client = httpClient;
    }

    public IActionResult Index()
    {
      return View();
    }

    [AuthorizeForScopes(Scopes = new[] { "api://4d0a0406-08d2-4b5d-8635-7a2d6d681c8b/Weather.Write" })]
    public async Task<IActionResult> Test([FromServices] ITokenAcquisition tokenAcquisition)
    {
      var accessToken = await tokenAcquisition.GetAccessTokenForUserAsync(new string[] { "api://4d0a0406-08d2-4b5d-8635-7a2d6d681c8b/Weather.Write" });
      client.DefaultRequestHeaders.Authorization =
        new AuthenticationHeaderValue("Bearer", accessToken);
      client.DefaultRequestHeaders.Accept.Add(
        new MediaTypeWithQualityHeaderValue("application/json"));

      //var responseMessage = await client.GetAsync("https://localhost:44387/WeatherForecast");
      var responseMessage = await client.PostAsync("https://localhost:44387/WeatherForecast", new StringContent(""));

      return Content("success");
    }

    public IActionResult Privacy()
    {
      ClaimsPrincipal claims = this.User;
      Claim firstName = claims.FindFirst(ClaimTypes.GivenName);
      Claim lastName = claims.FindFirst(ClaimTypes.Surname);
      ViewData["Message"] = $"Hello {firstName?.Value} {lastName?.Value}";

      return View();
    }

    [AllowAnonymous]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}
